import requests
from pprint import pprint

# Get - Obter todos recursos
resultado_get = requests.get('https://jsonplaceholder.typicode.com/todos')
pprint(resultado_get.json())